class Trabajador extends Persona{
    int salario;
}

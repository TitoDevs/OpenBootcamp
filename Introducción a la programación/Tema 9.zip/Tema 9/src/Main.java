class Main {

    public static void main(String[] args){
        Cliente cliente = new Cliente();
        cliente.edad = 28;
        cliente.telefono = 647738343;
        cliente.nombre = "Daniel";
        cliente.credito = 3244434;

        Trabajador trabajador = new Trabajador();
        trabajador.edad = 43;
        trabajador.telefono = 642343222;
        trabajador.nombre = "Juan";
        trabajador.salario = 5000;
    }
}

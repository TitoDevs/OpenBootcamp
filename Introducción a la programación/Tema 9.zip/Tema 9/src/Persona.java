class Persona {
    int edad;
    String nombre;
    int telefono;
}
